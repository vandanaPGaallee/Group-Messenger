package edu.buffalo.cse.cse486586.groupmessenger2;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OptionalDataException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StreamCorruptedException;
import java.io.StringReader;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.TreeMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * GroupMessengerActivity is the main Activity for the assignment.
 * 
 * @author stevko
 *
 */

/**
 * References
 * https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/locks/Lock.html
 * https://www.javatpoint.com/socket-programming
 * https://www.geeksforgeeks.org/implement-priorityqueue-comparator-java/
 * https://stackoverflow.com/questions/1066589/iterate-through-a-hashmap
 * https://stackoverflow.com/questions/2774608/how-do-i-access-nested-hashmaps-in-java
 */
public class GroupMessengerActivity extends Activity {
    static final String TAG = GroupMessengerActivity.class.getSimpleName();
    static final String[] ports = {"11108", "11112", "11116", "11120", "11124"};
    static final int SERVER_PORT = 10000;
    private ContentResolver mContentResolver = null;
    private static final String KEY_FIELD = "key";
    private static final String VALUE_FIELD = "value";
    private static final String TYPE_CAST = "cast";
    private static final String TYPE_PROPOSAL = "proposal";
    private static final String TYPE_AGREE = "agree";
    private String myPort = null;
    private Uri mUri = null;
    private int seq_num = 0;
    private int deliver = 0;
    private int msg_id = 0;
    private static String failed_process = null;
    private static int failed_process_count = 0;
    Lock lock = new ReentrantLock();

    PriorityQueue<MulticastMessage> pq = new PriorityQueue<MulticastMessage>(50, new MessageComparator());
    HashMap<String, TreeMap<String, Integer>> proposals = new HashMap<String, TreeMap<String, Integer>>();
    HashMap<String, String> process = new HashMap<String, String>() {{
        put("11108","A");
        put("11112","B");
        put("11116","C");
        put("11120","D");
        put("11124","E");
    }};

    private Uri buildUri(String scheme, String authority) {
        Uri.Builder uriBuilder = new Uri.Builder();
        uriBuilder.authority(authority);
        uriBuilder.scheme(scheme);
        return uriBuilder.build();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_messenger);
        mUri = buildUri("content", "edu.buffalo.cse.cse486586.groupmessenger2.provider");

        TextView tv = (TextView) findViewById(R.id.textView1);
        tv.setMovementMethod(new ScrollingMovementMethod());

        findViewById(R.id.button1).setOnClickListener(
                new OnPTestClickListener(tv, getContentResolver()));
        mContentResolver = getContentResolver();
        TelephonyManager tel = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
        myPort = String.valueOf((Integer.parseInt(portStr) * 2));
        try {
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
        } catch (IOException e) {
            Log.e(TAG, "Can't create a ServerSocket");
            return;
        }


        final EditText editText = (EditText) findViewById(R.id.editText1);


        findViewById(R.id.button4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String msg = editText.getText().toString() + "\n";
                editText.setText(""); // This is one way to reset the input box.
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, myPort);
            }
        });


    }

    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

        private boolean testInsert(String msg, int seq) {
            ContentValues cv = new ContentValues();
            cv.put(KEY_FIELD, Integer.toString(seq));
            cv.put(VALUE_FIELD, msg);
            try {

                mContentResolver.insert(mUri, cv);
                Log.d("Value inserted - ", seq + " " + msg );
            } catch (Exception e) {
                Log.e(TAG, e.toString());
                return false;
            }

            return true;
        }


        private void updateQueue(MulticastMessage obj) {
            seq_num = Math.max(seq_num, obj.seq_no);
            obj.setStatus(true);
            Iterator it = pq.iterator();
            for (MulticastMessage m1 : pq) {
                MulticastMessage obj2 = (MulticastMessage) m1;
                if(obj2.getM_id().equals(obj.getM_id())){
                    lock.lock();
                    pq.remove(obj2);
                    pq.add(obj);
                    lock.unlock();
                    break;
                }
            }
            Log.d("tested", "Failed proc from Queue  - " + failed_process + " " + String.valueOf(failed_process_count));
            Log.d("tested", "Update Queue PriorityQueue before  - " + pq.toString());
            while (!pq.isEmpty() && (pq.peek().status || pq.peek().source_id.equals(failed_process)) ) {
                lock.lock();
                if(pq.peek().source_id.equals(failed_process) && !pq.peek().status) {
                    pq.poll();
                } else if(pq.peek().status){
                    MulticastMessage o = pq.poll();
                    testInsert(o.getMessage(), deliver ++);
                    publishProgress(o.getMessage(), String.valueOf(deliver), String.valueOf(o.getSeq_no()), o.getProcess_id(), o.getM_id());
                }
                lock.unlock();
            }
            Log.d("tested", "Update Queue PriorityQueue after  - " + pq.toString());
        }

        @Override
        protected Void doInBackground(ServerSocket... sockets) {
            ServerSocket serverSocket = sockets[0];
            try {
                while (true) {
                    MulticastMessage obj = null;
                    Socket socketline = serverSocket.accept();
                    ObjectInputStream in = new ObjectInputStream(socketline.getInputStream());
                    obj = (MulticastMessage) in.readObject();
                    if (obj.getType().equals(TYPE_CAST)) {
                        ObjectOutputStream os = new ObjectOutputStream(socketline.getOutputStream());
                        obj.setProcess_id(myPort);
                        lock.lock();
                        obj.setSeq_no(++seq_num);
                        lock.unlock();
                        obj.setType(TYPE_PROPOSAL);
                        obj.setStatus(false);
                        pq.add(obj);
                        os.writeObject(obj);
                        BufferedReader br = new BufferedReader(new InputStreamReader(socketline.getInputStream()));
                        Log.d(TAG, (br.readLine().equals("Received"))? "Received ACk for sent proposal":"No Ack for sent proposal");
                    } else if (obj.getType().equals(TYPE_AGREE)) {
                        if(failed_process == null && obj.getFailed_process() != null) {
                            failed_process =  obj.getFailed_process();
                            Log.d("tested" , " Received failed process from typecast" + failed_process);
                        }
                        Log.d("tested" , " Received failed process from typecast" + obj.getFailed_process());
                        updateQueue(obj);
                        OutputStream o = socketline.getOutputStream();
                        PrintWriter out = new PrintWriter(o, true);
                        out.println("Received");
//                        out.flush();
                    }
                }
            } catch (NullPointerException e) {
                Log.e(TAG, "Server Null pointer exception");
            } catch (UnknownHostException e) {
                Log.e(TAG, "ServerTask UnknownHostException");
            } catch (IOException e) {
                Log.e(TAG, "server socket connection exception");
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }

            return null;
        }

        protected void onProgressUpdate(String...strings) {
            String strReceived = strings[0].trim();
            TextView remoteTextView = (TextView) findViewById(R.id.textView1);
            remoteTextView.append(strings[1].trim() + " - " + strings[4].trim() + " - " +strings[2].trim() + " - " + strings[3].trim() + " - " +strReceived + "\t\n");
            return;
        }
    }


    private class ClientTask extends AsyncTask<String, Void, Void> {

        private MulticastMessage initializeObject(String message, String port) {
            MulticastMessage obj = new MulticastMessage();
            obj.setM_id(process.get(port) + String.valueOf(msg_id));
            obj.setType(TYPE_CAST);
            obj.setSource_id(port);
            obj.setProcess_id(port);
            obj.setSeq_no(seq_num);
            obj.setStatus(false);
            obj.setMessage(message);
            obj.setFailed_process(failed_process);
            return obj;
        }

        private void AgreeProposal(MulticastMessage obj){
            String msg_id = obj.getM_id(), port = obj.getProcess_id();
            int seq = obj.seq_no;
            if(proposals.containsKey(msg_id)) {
                TreeMap tmap = new TreeMap();
                tmap = proposals.get(msg_id);
                if(!tmap.containsKey(port)){
                    tmap.put(port, seq);
                }
                proposals.put(msg_id, tmap);
            } else {
                proposals.put(msg_id, new TreeMap<String, Integer>());
                proposals.get(msg_id).put(port, seq);
            }
            Log.d("tested", String.valueOf(proposals.get(msg_id).size()));
        }

        public void  sendAgreedProposal(MulticastMessage obj) {
            if(obj == null) {
                Log.e(TAG, "Received null obj" + obj);
                return;
            }
            Log.d("tested", " process " + failed_process + " " + String.valueOf(failed_process_count) );
            obj.setType(TYPE_AGREE);
            for (int i = 0; i < ports.length; i++) {
                if (ports[i].equals(failed_process)){
                    continue;
                }
                try {
                    Socket socket2 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                            Integer.parseInt(ports[i]));
                    socket2.setSoTimeout(500);
                    ObjectOutputStream os = new ObjectOutputStream(socket2.getOutputStream());
                    obj.setFailed_process(failed_process);
                    os.writeObject(obj);
                    BufferedReader br = new BufferedReader(new InputStreamReader(socket2.getInputStream()));
                    String res = null;
                    while (!socket2.isClosed()) {
                        res = br.readLine();
                        if(res.equals("Received") || null != res) {
                            Log.d("tested", " Agree success " + res + " " + ports[i]);
                            socket2.close();
                        }
                    }
                    socket2.close();
                }catch (IOException e) {
                    if(!ports[i].equals(failed_process)) {
                        failed_process_count ++;
                        failed_process = ports[i];
                    }
                    Log.e(TAG, "agree Io Exception - " + String.valueOf(failed_process_count) + " " + failed_process);
                } catch (NullPointerException e) {
                    Log.e(TAG, "Null pointer  agree Exception - " + String.valueOf(failed_process_count) + " " + failed_process);
                }
            }

        }

        @Override
        protected Void doInBackground(String... msgs) {
            String port = msgs[1];
            String msgToSend = msgs[0];
            ++msg_id;
            MulticastMessage msg_obj = initializeObject(msgToSend, port);
            Log.d("tested", "Received Message - " + msgToSend);
            for (int i = 0; i < ports.length; i++) {
                try {
                        if (ports[i].equals(failed_process)){
                            continue;
                        }
                        Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                Integer.parseInt(ports[i]));
                        socket.setSoTimeout(500);
                        ObjectOutputStream os = new ObjectOutputStream(socket.getOutputStream());
                        msg_obj.setFailed_process(failed_process);
                        os.writeObject(msg_obj);
                        ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
                        MulticastMessage obj = null;
                        while (!socket.isClosed()) {
                            obj = (MulticastMessage) in.readObject();
                            Log.d("tested", "innerloop");
                            if(obj != null) {
                                OutputStream o = socket.getOutputStream();
                                PrintWriter out = new PrintWriter(o, true);
                                out.println("Received");
                                out.flush();
                                socket.close();
                            }
                        }

                        if (obj.getType().equals(TYPE_PROPOSAL)) {
                            AgreeProposal(obj);
                        }

                } catch (NullPointerException e) {
                    if(!ports[i].equals(failed_process) ) {
                        failed_process_count ++;
                        failed_process = ports[i];
                    }
                    Log.e("tested", "ClientTask Null pointer send msg Exception");
                }
                catch (UnknownHostException e) {
                    Log.e(TAG, "ClientTask UnknownHostException");
                }
                catch (IOException e) {
                    if(!ports[i].equals(failed_process)) {
                        failed_process_count ++;
                        failed_process = ports[i];
                    }
                    Log.e("tested", "send message Io Exception - " + String.valueOf(failed_process_count) + " " + failed_process);
                }
                catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
            ChooseMaxProposal(msg_obj);

            return null;
        }

        private void ChooseMaxProposal(MulticastMessage obj) {
            int agreed_seq;
            String agreed_proc = null;
            TreeMap tmap = new TreeMap();
            tmap = proposals.get(obj.getM_id());
            if(failed_process_count > 1) {
                Log.e("tested", "failed process count " + String.valueOf(failed_process_count));
            }
            if(tmap.size() == (5 - failed_process_count)) {
                agreed_seq = (Integer) Collections.max(tmap.values());
                Iterator iter = tmap.entrySet().iterator();
                while(iter.hasNext()) {
                    Map.Entry m = (Map.Entry)iter.next();
                    if(m.getValue() == (Integer)agreed_seq) {
                        agreed_proc = (String) m.getKey();
                        break;
                    }
                }
                obj.setSeq_no(agreed_seq);
                obj.setProcess_id(agreed_proc);
                Log.d("tested", "Ready for agree proposal" +  obj.toString());
                sendAgreedProposal(obj);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_group_messenger, menu);
        return true;
    }
}
