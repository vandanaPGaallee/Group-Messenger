package edu.buffalo.cse.cse486586.groupmessenger2;

import java.io.Serializable;
import java.util.Comparator;

/**
 * References
 * https://www.geeksforgeeks.org/implement-priorityqueue-comparator-java/
 */

public class MulticastMessage implements Serializable {
    public String m_id;
    public String source_id;
    public int seq_no;
    public String process_id;
    public String message;
    public boolean status;
    public String type;
    public  String failed_process;

    public String getFailed_process() {
        return failed_process;
    }

    public void setFailed_process(String failed_process) {
        this.failed_process = failed_process;
    }



    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getM_id() {
        return m_id;
    }

    public void setM_id(String m_id) {
        this.m_id = m_id;
    }

    public String getSource_id() {
        return source_id;
    }

    public void setSource_id(String source_id) {
        this.source_id = source_id;
    }

    public int getSeq_no() {
        return seq_no;
    }

    public void setSeq_no(int seq_no) {
        this.seq_no = seq_no;
    }

    public String getProcess_id() {
        return process_id;
    }

    public void setProcess_id(String process_id) {
        this.process_id = process_id;
    }

    @Override
    public String toString() {
        return m_id + ", " + source_id + ", " + process_id + ", " + seq_no + ", " + message + ", " + status + ", " + type;
    }

}


class MessageComparator implements Comparator<MulticastMessage> {

    public int compare(MulticastMessage s1, MulticastMessage s2) {
        if(s1.getSeq_no() < s2.getSeq_no()){
            return  -1;
        }

        if(s1.getSeq_no() > s2.getSeq_no()){
            return  1;
        }

        if(s1.getSeq_no() == s2.getSeq_no()){
            if (Integer.parseInt(s1.getProcess_id()) < Integer.parseInt(s2.getProcess_id())){
                return  1;
            }
            return  -1;
        }
        return 0;
    }
}